
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'angulararchitecture',
  applicationName: 'quicken-contacts',
  appUid: '9LXvrCZdfQvCbytdvD',
  orgUid: 't0j8SYMLMlk4rk6X5M',
  deploymentUid: 'ff176047-1de4-4fb9-b92f-0dd445f2d0a1',
  serviceName: 'contacts',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.8.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'contacts-dev-api', timeout: 6 };

try {
  const userHandler = require('./_optimize/contacts-dev-api/./apps/contacts/src/lambda.js');
  module.exports.handler = serverlessSDK.handler(userHandler.main, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}