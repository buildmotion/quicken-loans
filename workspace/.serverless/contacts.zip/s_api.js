
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'angulararchitecture',
  applicationName: 'quicken-contacts',
  appUid: '9LXvrCZdfQvCbytdvD',
  orgUid: 't0j8SYMLMlk4rk6X5M',
  deploymentUid: 'a2224f5c-35a8-44b3-9172-9cb961e1d334',
  serviceName: 'contacts',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.8.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'contacts-dev-api', timeout: 6 };

try {
  const userHandler = require('./_optimize/contacts-dev-api/./apps/contacts/src/lambda.js');
  module.exports.handler = serverlessSDK.handler(userHandler.main, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}