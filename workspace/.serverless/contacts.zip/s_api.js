
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'angulararchitecture',
  applicationName: 'quicken-contacts',
  appUid: '9LXvrCZdfQvCbytdvD',
  orgUid: 't0j8SYMLMlk4rk6X5M',
  deploymentUid: 'ffabf689-c346-4139-b3d6-7882c0e181eb',
  serviceName: 'contacts',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.8.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'contacts-dev-api', timeout: 6 };

try {
  const userHandler = require('./_optimize/contacts-dev-api/./apps/contacts/src/lambda.js');
  module.exports.handler = serverlessSDK.handler(userHandler.main, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}